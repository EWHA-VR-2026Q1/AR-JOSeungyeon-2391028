using System;
using System.Collections.Generic;

[Serializable]
public class WorldData
{
    public TransformData playerData;
    public List<TransformData> objectDataList = new List<TransformData>();
}