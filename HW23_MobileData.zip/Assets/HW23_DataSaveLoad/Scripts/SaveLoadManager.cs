using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class SaveLoadManager : MonoBehaviour
{
    [Header("Player")]
    public Transform player;

    [Header("Tracked Objects (�ּ� 2�� �̻�)")]
    public List<Transform> trackedObjects = new List<Transform>();

    [Header("Options")]
    public bool autoLoadOnStart = true;
    public bool autoSaveOnPauseQuit = true;

    private string SavePath => Path.Combine(Application.persistentDataPath, "world_save.json");

    void Start()
    {
        if (autoLoadOnStart && File.Exists(SavePath))
            Load();
    }

    public void Save()
    {
        WorldData data = new WorldData();

        if (player != null)
            data.playerData = new TransformData(player.name, player);

        foreach (var obj in trackedObjects)
        {
            if (obj != null)
                data.objectDataList.Add(new TransformData(obj.name, obj));
        }

        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SavePath, json);

        Debug.Log($"[SaveLoad] Saved �� {SavePath}\n{json}");
    }

    public void Load()
    {
        if (!File.Exists(SavePath))
        {
            Debug.LogWarning("[SaveLoad] No save file found.");
            return;
        }

        string json = File.ReadAllText(SavePath);
        WorldData data = JsonUtility.FromJson<WorldData>(json);

        if (data.playerData != null && player != null)
            data.playerData.ApplyTo(player);

        foreach (var saved in data.objectDataList)
        {
            Transform target = trackedObjects.Find(o => o != null && o.name == saved.objectName);
            if (target != null) saved.ApplyTo(target);
        }

        Debug.Log("[SaveLoad] Loaded.");
    }

    void OnApplicationPause(bool pause)
    {
        if (autoSaveOnPauseQuit && pause) Save();
    }

    void OnApplicationQuit()
    {
        if (autoSaveOnPauseQuit) Save();
    }

    [ContextMenu("Delete Save File")]
    public void DeleteSave()
    {
        if (File.Exists(SavePath))
        {
            File.Delete(SavePath);
            Debug.Log("[SaveLoad] Save deleted.");
        }
    }
}