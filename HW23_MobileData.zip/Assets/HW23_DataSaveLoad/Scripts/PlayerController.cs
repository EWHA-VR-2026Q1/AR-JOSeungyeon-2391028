using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float rotSpeed = 90f;

    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        transform.Translate(new Vector3(h, 0, v) * moveSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.Q)) transform.Rotate(0, -rotSpeed * Time.deltaTime, 0);
        if (Input.GetKey(KeyCode.E)) transform.Rotate(0, rotSpeed * Time.deltaTime, 0);
    }
}