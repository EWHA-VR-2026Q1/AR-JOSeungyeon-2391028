using System;
using UnityEngine;

[Serializable]
public class TransformData
{
    public string objectName;
    public Vector3 position;
    public Vector3 rotation;

    public TransformData() { }

    public TransformData(string name, Transform t)
    {
        objectName = name;
        position = t.position;
        rotation = t.rotation.eulerAngles;
    }

    public void ApplyTo(Transform t)
    {
        t.position = position;
        t.rotation = Quaternion.Euler(rotation);
    }
}