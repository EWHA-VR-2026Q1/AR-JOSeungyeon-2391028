using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class GPSManager : MonoBehaviour
{
    [Header("Target Location (��� ��ǥ - Inspector���� ����)")]
    public double targetLatitude = 37.5665;
    public double targetLongitude = 126.9780;
    public float triggerRadiusMeters = 50f;

    [Header("UI")]
    public TMP_Text statusText;

    [Header("Scene")]
    public string mobileDataSceneName = "HW23_MobileData";

    [Header("Mock Mode (PC �׽�Ʈ��)")]
    public bool useMockGPS = true;
    public double mockLatitude = 37.5665;
    public double mockLongitude = 126.9780;

    private bool sceneLoaded = false;
    private bool gpsRunning = false;
    private float inRangeTime = 0f;

    IEnumerator Start()
    {
#if !UNITY_EDITOR && (UNITY_ANDROID || UNITY_IOS)
        useMockGPS = false;
#endif

        if (useMockGPS)
        {
            SetStatus("[MOCK MODE]\nPC���� �ùķ��̼� ��\n��ư ������ ��� ����");
            yield break;
        }

#if UNITY_ANDROID
        if (!UnityEngine.Android.Permission.HasUserAuthorizedPermission(
                UnityEngine.Android.Permission.FineLocation))
        {
            UnityEngine.Android.Permission.RequestUserPermission(
                UnityEngine.Android.Permission.FineLocation);
            yield return new WaitForSeconds(2f);
        }
#endif

        if (!Input.location.isEnabledByUser)
        {
            SetStatus("Location service NOT enabled");
            yield break;
        }

        Input.location.Start(5f, 5f);

        int maxWait = 20;
        while (Input.location.status == LocationServiceStatus.Initializing && maxWait > 0)
        {
            yield return new WaitForSeconds(1);
            maxWait--;
        }

        if (maxWait <= 0)
        {
            SetStatus("GPS Init Timeout");
            yield break;
        }

        if (Input.location.status == LocationServiceStatus.Failed)
        {
            SetStatus("GPS Failed");
            yield break;
        }

        gpsRunning = true;
        SetStatus("GPS Started");
    }

    void Update()
    {
        if (sceneLoaded) return;

        double lat, lon;

        if (useMockGPS)
        {
            lat = mockLatitude;
            lon = mockLongitude;
        }
        else
        {
            if (!gpsRunning) return;
            if (Input.location.status != LocationServiceStatus.Running) return;
            lat = Input.location.lastData.latitude;
            lon = Input.location.lastData.longitude;
        }

        float distance = (float)HaversineMeters(lat, lon, targetLatitude, targetLongitude);

        SetStatus(
            $"Mode: {(useMockGPS ? "MOCK" : "GPS")}\n" +
            $"My Pos: {lat:F6}, {lon:F6}\n" +
            $"Target: {targetLatitude:F6}, {targetLongitude:F6}\n" +
            $"Distance: {distance:F1} m\n" +
            $"Radius: {triggerRadiusMeters} m\n" +
            $"In Range: {(distance <= triggerRadiusMeters ? "YES" : "NO")}"
        );

        if (distance <= triggerRadiusMeters)
        {
            inRangeTime += Time.deltaTime;
            if (inRangeTime >= 3f)
            {
                EnterPlace();
            }
        }
        else
        {
            inRangeTime = 0f;
        }
    }

    public void TriggerMockEnter()
    {
        mockLatitude = targetLatitude;
        mockLongitude = targetLongitude;
        Debug.Log("[GPS] Mock enter triggered.");
    }

    void EnterPlace()
    {
        if (sceneLoaded) return;
        sceneLoaded = true;

        PlaceContext.Latitude = targetLatitude;
        PlaceContext.Longitude = targetLongitude;
        PlaceContext.Radius = triggerRadiusMeters;
        PlaceContext.HasContext = true;

        Debug.Log("[GPS] Entered place. Loading scene...");

        if (Input.location.status == LocationServiceStatus.Running)
            Input.location.Stop();

        SceneManager.LoadScene(mobileDataSceneName);
    }

    void SetStatus(string s)
    {
        if (statusText != null) statusText.text = s;
        Debug.Log("[GPS] " + s);
    }

    public static double HaversineMeters(double lat1, double lon1, double lat2, double lon2)
    {
        double R = 6371000.0;
        double dLat = (lat2 - lat1) * Mathf.Deg2Rad;
        double dLon = (lon2 - lon1) * Mathf.Deg2Rad;
        double a = System.Math.Sin(dLat / 2) * System.Math.Sin(dLat / 2) +
                   System.Math.Cos(lat1 * Mathf.Deg2Rad) * System.Math.Cos(lat2 * Mathf.Deg2Rad) *
                   System.Math.Sin(dLon / 2) * System.Math.Sin(dLon / 2);
        double c = 2 * System.Math.Atan2(System.Math.Sqrt(a), System.Math.Sqrt(1 - a));
        return R * c;
    }

    void OnDestroy()
    {
        if (Input.location.status == LocationServiceStatus.Running)
            Input.location.Stop();
    }
}