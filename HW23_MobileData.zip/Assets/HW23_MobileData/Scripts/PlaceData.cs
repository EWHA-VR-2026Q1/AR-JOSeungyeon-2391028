using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class PlaceTransformData
{
    public string objectName;
    public Vector3 position;
    public Vector3 rotation;
}

[Serializable]
public class PlaceData
{
    public double targetLatitude;
    public double targetLongitude;
    public float radiusMeters;
    public List<PlaceTransformData> objects = new List<PlaceTransformData>();
}