﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class PlaceObjectManager : MonoBehaviour
{
    [Header("Tracked Objects (최소 1개)")]
    public List<Transform> objectsToTrack = new List<Transform>();

    [Header("Target Cube (조작 대상)")]
    public Transform targetCube;
    public float moveStep = 0.5f;
    public float rotStep = 45f;

    [Header("UI")]
    public TMP_Text placeInfoText;

    [Header("GPS Scene Name")]
    public string gpsSceneName = "GPS";

    private string SavePath
    {
        get
        {
            // 좌표 기반 파일명 → 장소별 저장 분리
            string key = $"{PlaceContext.Latitude:F5}_{PlaceContext.Longitude:F5}";
            // 음수/소수점이 파일명에 들어가도 OK이지만 -를 m으로 바꿔서 안전하게
            key = key.Replace("-", "m").Replace(".", "p");
            return Path.Combine(Application.persistentDataPath, $"place_{key}.json");
        }
    }

    void Start()
    {
        UpdateInfoText();
        Load();
    }

    void UpdateInfoText()
    {
        if (placeInfoText == null) return;
        placeInfoText.text =
            $"Place: {PlaceContext.Latitude:F5}, {PlaceContext.Longitude:F5}\n" +
            $"Radius: {PlaceContext.Radius} m\n" +
            $"Save Path: {SavePath}";
    }

    // ===== 버튼에서 호출 =====
    public void MoveX()
    {
        if (targetCube != null)
            targetCube.position += Vector3.right * moveStep;
    }

    public void MoveZ()
    {
        if (targetCube != null)
            targetCube.position += Vector3.forward * moveStep;
    }

    public void RotateY()
    {
        if (targetCube != null)
            targetCube.Rotate(0, rotStep, 0);
    }

    public void Save()
    {
        PlaceData data = new PlaceData
        {
            targetLatitude = PlaceContext.Latitude,
            targetLongitude = PlaceContext.Longitude,
            radiusMeters = PlaceContext.Radius
        };

        foreach (var t in objectsToTrack)
        {
            if (t == null) continue;
            data.objects.Add(new PlaceTransformData
            {
                objectName = t.name,
                position = t.position,
                rotation = t.rotation.eulerAngles
            });
        }

        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(SavePath, json);

        Debug.Log($"[Place] Saved → {SavePath}\n{json}");

        if (placeInfoText != null)
            placeInfoText.text += "\n[SAVED ✓]";
    }

    public void Load()
    {
        if (!File.Exists(SavePath))
        {
            Debug.Log($"[Place] No save file at {SavePath}");
            return;
        }

        string json = File.ReadAllText(SavePath);
        PlaceData data = JsonUtility.FromJson<PlaceData>(json);

        foreach (var saved in data.objects)
        {
            Transform t = objectsToTrack.Find(o => o != null && o.name == saved.objectName);
            if (t == null) continue;
            t.position = saved.position;
            t.rotation = Quaternion.Euler(saved.rotation);
        }

        Debug.Log("[Place] Restored from save.");
    }

    public void BackToGPS()
    {
        Save();  // 나가기 전 자동 저장
        SceneManager.LoadScene(gpsSceneName);
    }

    void OnApplicationPause(bool pause) { if (pause) Save(); }
    void OnApplicationQuit() { Save(); }
}