using UnityEngine;
using TMPro;

/// <summary>
/// HW24_ARInfo - 책 리뷰 입력 핸들러
/// TMP_InputField와 모바일 가상 키보드를 연동하고,
/// 사용자가 입력한 리뷰 텍스트를 화면에 표시한다.
///
/// 사용 방법:
///  - 씬에 TMP_InputField를 만들고 이 스크립트를 임의의 오브젝트에 부착.
///  - ReviewInputField, ReviewDisplayText를 Inspector에서 연결.
///  - InputField의 On Value Changed (String) 이벤트에 OnReviewChanged 등록 (실시간 표시용).
///  - InputField의 On End Edit (String) 이벤트에 OnReviewSubmitted 등록 (입력 완료 시).
///  - "리뷰 작성" 버튼의 OnClick에 OpenKeyboard 등록 (모바일 키보드 강제 활성화용).
/// </summary>
public class BookReviewInput : MonoBehaviour
{
    [Header("입력 필드 / 표시 텍스트")]
    public TMP_InputField ReviewInputField;
    [Tooltip("사용자가 입력한 리뷰가 표시될 텍스트")]
    public TMP_Text ReviewDisplayText;

    [Header("표시 형식")]
    public string Prefix = "내 리뷰: ";
    public string EmptyMessage = "아직 작성된 리뷰가 없습니다.";

    // 모바일 가상 키보드 직접 제어용 (TMP_InputField가 자동으로 띄우지만,
    // 버튼으로 명시적으로 띄우고 싶을 때 사용)
    private TouchScreenKeyboard _keyboard;

    private void Start()
    {
        if (ReviewDisplayText != null) ReviewDisplayText.text = EmptyMessage;
    }

    /// <summary>
    /// InputField의 On Value Changed에 연결 → 입력 중인 텍스트를 실시간 표시.
    /// </summary>
    public void OnReviewChanged(string text)
    {
        if (ReviewDisplayText == null) return;
        ReviewDisplayText.text = string.IsNullOrEmpty(text) ? EmptyMessage : Prefix + text;
    }

    /// <summary>
    /// InputField의 On End Edit에 연결 → 입력 완료(Done) 시 최종 반영.
    /// </summary>
    public void OnReviewSubmitted(string text)
    {
        if (string.IsNullOrEmpty(text))
        {
            if (ReviewDisplayText != null) ReviewDisplayText.text = EmptyMessage;
            Debug.Log("<color=yellow>BookReviewInput: 빈 리뷰 입력</color>");
            return;
        }

        if (ReviewDisplayText != null) ReviewDisplayText.text = Prefix + text;
        Debug.Log($"<color=green>BookReviewInput: 리뷰 입력 완료 → {text}</color>");
    }

    /// <summary>
    /// "리뷰 작성" 버튼에 연결하면, 모바일에서 가상 키보드를 명시적으로 띄운다.
    /// (TMP_InputField를 선택하는 것만으로도 키보드가 뜨지만,
    ///  별도 버튼 흐름이 필요할 때 사용.)
    /// </summary>
    public void OpenKeyboard()
    {
        if (ReviewInputField != null)
        {
            // 가장 자연스러운 방법: InputField 자체를 활성/포커스
            ReviewInputField.Select();
            ReviewInputField.ActivateInputField();
        }

        // 모바일 환경에서 한 번 더 확실하게 키보드를 띄움
        if (Application.isMobilePlatform)
        {
            string initial = ReviewInputField != null ? ReviewInputField.text : "";
            _keyboard = TouchScreenKeyboard.Open(initial, TouchScreenKeyboardType.Default);
        }

        Debug.Log("<color=green>BookReviewInput: 모바일 키보드 열기 요청</color>");
    }

    private void Update()
    {
        // OpenKeyboard()로 직접 띄운 경우, 입력값을 InputField/표시에 동기화
        if (_keyboard != null && _keyboard.active)
        {
            string t = _keyboard.text;
            if (ReviewInputField != null) ReviewInputField.text = t;
            OnReviewChanged(t);

            if (_keyboard.status == TouchScreenKeyboard.Status.Done)
            {
                OnReviewSubmitted(t);
                _keyboard = null;
            }
            else if (_keyboard.status == TouchScreenKeyboard.Status.Canceled)
            {
                Debug.Log("<color=yellow>BookReviewInput: 키보드 입력 취소</color>");
                _keyboard = null;
            }
        }
    }
}
