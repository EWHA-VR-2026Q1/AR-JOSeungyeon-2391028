using UnityEngine;
using TMPro;

/// <summary>
/// HW24_ARInfo - 책 정보 인터페이스 컨트롤러
/// Image Target(책 표지) 인식 시 정보 패널을 보여주고,
/// 버튼/입력에 따라 정보를 갱신하는 핵심 스크립트.
///
/// 사용 방법:
///  - Vuforia ImageTarget의 자식으로 InfoPanel(Canvas)을 두고,
///    이 스크립트를 ImageTarget 또는 InfoPanel에 부착한다.
///  - Inspector에서 아래 필드들을 연결한다.
/// </summary>
public class BookInfoInterface : MonoBehaviour
{
    [Header("정보 패널 루트 (인식 시 켜고, 사라지면 끈다)")]
    [Tooltip("책 정보가 들어있는 패널/캔버스 루트 오브젝트")]
    public GameObject InfoPanel;

    [Header("정보 요소 (최소 3개 이상)")]
    public TMP_Text TitleText;        // 제목
    public TMP_Text AuthorText;       // 저자
    public TMP_Text DescriptionText;  // 설명
    [Tooltip("별점 아이콘(★)을 모아둔 부모 오브젝트의 자식 Image들")]
    public GameObject[] StarIcons;    // 별점 아이콘 (상태 정보)

    [Header("책 데이터")]
    public string BookTitle = "신곡 (La Divina Commedia)";
    [TextArea] public string BookAuthor = "단테 알리기에리 (Dante Alighieri)";
    [TextArea] public string BookDescription =
        "지옥, 연옥, 천국을 여행하는 중세 서사시.\n현실의 책 표지를 인식하면 이 정보가 겹쳐 보입니다.";
    [Range(0, 5)] public int Rating = 4;

    [Header("인터랙션 결과 표시 (버튼 클릭 시)")]
    [Tooltip("버튼을 눌렀을 때 추가로 보여줄 텍스트 (예: 한 줄 평, 오디오 설명 안내 등)")]
    public TMP_Text ActionResultText;
    [TextArea] public string ActionMessage =
        "✔ 오디오 설명 재생 (현실 책 위에서 정보가 살아납니다)";

    [Header("오디오 (선택)")]
    public AudioSource DescriptionAudio;


    private void Start()
    {
        // 시작 시에는 패널을 숨겨둔다 (인식되어야 보임)
        if (InfoPanel != null) InfoPanel.SetActive(false);
        ApplyBookData();
        if (ActionResultText != null) ActionResultText.text = "";
    }

    /// <summary>
    /// 책 데이터를 UI에 반영한다.
    /// </summary>
    public void ApplyBookData()
    {
        if (TitleText != null) TitleText.text = BookTitle;
        if (AuthorText != null) AuthorText.text = "저자: " + BookAuthor;
        if (DescriptionText != null) DescriptionText.text = BookDescription;
        UpdateStars();
    }

    /// <summary>
    /// 별점 아이콘을 Rating 만큼 켜고 나머지는 끈다.
    /// </summary>
    private void UpdateStars()
    {
        if (StarIcons == null) return;
        for (int i = 0; i < StarIcons.Length; i++)
        {
            if (StarIcons[i] != null)
                StarIcons[i].SetActive(i < Rating);
        }
    }

    /// <summary>
    /// Vuforia의 OnTargetFound(추적 시작) 이벤트에 연결.
    /// Default Observer Event Handler의 On Target Found()에 등록한다.
    /// </summary>
    public void OnTargetFound()
    {
        if (InfoPanel != null) InfoPanel.SetActive(true);
        ApplyBookData();
        Debug.Log("<color=cyan>BookInfoInterface: 책 표지 인식됨 → 정보 패널 표시</color>");
    }

    /// <summary>
    /// Vuforia의 OnTargetLost(추적 해제) 이벤트에 연결.
    /// </summary>
    public void OnTargetLost()
    {
        if (InfoPanel != null) InfoPanel.SetActive(false);
        Debug.Log("<color=cyan>BookInfoInterface: 책 표지 추적 해제 → 정보 패널 숨김</color>");
    }

    /// <summary>
    /// 정보 버튼 클릭 시 호출 (Button의 OnClick에 등록).
    /// 추가 정보 표시 + 오디오 재생.
    /// </summary>
    public void OnInfoButtonClicked()
    {
        if (ActionResultText != null) ActionResultText.text = ActionMessage;
        if (DescriptionAudio != null && !DescriptionAudio.isPlaying)
            DescriptionAudio.Play();
        Debug.Log("<color=cyan>BookInfoInterface: 정보 버튼 클릭 → 추가 정보/오디오</color>");
    }

    /// <summary>
    /// 별점 변경용 (선택). 버튼에 연결해 0~5 사이로 조정 가능.
    /// </summary>
    public void SetRating(int value)
    {
        Rating = Mathf.Clamp(value, 0, 5);
        UpdateStars();
    }
}
