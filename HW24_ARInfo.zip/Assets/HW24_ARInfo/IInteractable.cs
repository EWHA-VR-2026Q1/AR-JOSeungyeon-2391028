using UnityEngine;

/// <summary>
/// 상호작용 가능한 오브젝트가 구현해야 하는 인터페이스.
/// Trigger_PhysicalMousePointer 등에서 이 타입으로 OnClick 등을 호출한다.
/// (패키지 import 시 누락되어 별도로 정의)
/// </summary>
public interface IInteractable
{
    void OnEnter();
    void OnEnter(GameObject sender);

    void OnStay();
    void OnStay(GameObject sender);

    void OnExit();
    void OnExit(GameObject sender);

    void OnClick();
    void OnClick(GameObject sender);

    void OnInteract(GameObject sender);
}
