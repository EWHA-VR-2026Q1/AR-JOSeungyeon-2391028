using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// HW20_ARInteraction
/// Tap(선택) → Drag(이동) → Snap(근처 포인트로 흡착) → Lerp(부드러운 이동)
/// 하나의 오브젝트에 부착하여 화면 터치만으로 조작 가능하게 함
/// </summary>
public class ARObjectController : MonoBehaviour
{
    [Header("스냅 설정")]
    [Tooltip("스냅 대상이 되는 오브젝트의 태그")]
    [SerializeField] private string snapPointTag = "SnapPoint";

    [Tooltip("스냅 후보 포인트가 이 거리 이내에 있으면 스냅됨 (월드 단위)")]
    [SerializeField] private float snapDistance = 0.15f;

    [Header("Lerp 설정")]
    [Tooltip("Lerp 보간 속도 (값이 클수록 빠르게 도착)")]
    [Range(1f, 20f)]
    [SerializeField] private float lerpSpeed = 8f;

    [Tooltip("이 거리 이내에 도달하면 Lerp 종료")]
    [SerializeField] private float arriveThreshold = 0.005f;

    // 내부 상태
    private Camera mainCamera;
    private bool isSelected = false;     // Tap으로 선택된 상태
    private bool isDragging = false;     // Drag 중인 상태
    private bool isLerping = false;      // Lerp로 이동 중인 상태

    private float zDistance;             // 카메라로부터의 깊이
    private Vector3 dragOffset;          // 클릭 지점과 중심의 차이
    private Vector3 lerpTarget;          // Lerp 목표 지점

    // 스냅 후보들을 캐싱 (씬 시작 시 한 번만 검색)
    private List<Transform> snapPoints = new List<Transform>();

    private void Awake()
    {
        mainCamera = Camera.main;
        CacheSnapPoints();
    }

    private void CacheSnapPoints()
    {
        GameObject[] points = GameObject.FindGameObjectsWithTag(snapPointTag);
        foreach (GameObject p in points)
        {
            snapPoints.Add(p.transform);
        }
        Debug.Log($"[ARObjectController] 스냅 포인트 {snapPoints.Count}개를 감지했습니다.");
    }

    private void Update()
    {
        HandlePointerInput();
        HandleLerpMovement();
    }

    // -------------------------------------------------------------
    // 입력 처리: Tap / Drag
    // -------------------------------------------------------------
    private void HandlePointerInput()
    {
        var pointer = Pointer.current;
        if (pointer == null) return;

        Vector2 screenPos = pointer.position.ReadValue();

        // 누르기 시작 → Tap 판정 + Drag 준비
        if (pointer.press.wasPressedThisFrame)
        {
            TryTapAndStartDrag(screenPos);
        }

        // 드래그 중
        if (isDragging)
        {
            ExecuteDrag(screenPos);
        }

        // 손을 뗌 → Drag 종료 + Snap 판정 → Lerp 시작
        if (pointer.press.wasReleasedThisFrame && isDragging)
        {
            EndDragAndTrySnap();
        }
    }

    private void TryTapAndStartDrag(Vector2 screenPos)
    {
        Ray ray = mainCamera.ScreenPointToRay(screenPos);
        if (Physics.Raycast(ray, out RaycastHit hit))
        {
            if (hit.transform == transform)
            {
                // Tap: 선택 상태로 전환
                isSelected = true;
                isDragging = true;
                isLerping = false;  // 진행 중이던 Lerp는 중단 (사용자 입력 우선)

                // 카메라로부터의 현재 깊이 기억
                zDistance = mainCamera.WorldToScreenPoint(transform.position).z;

                // 클릭 지점과 중심의 차이를 저장 (자연스러운 드래그)
                Vector3 clickWorldPos = mainCamera.ScreenToWorldPoint(
                    new Vector3(screenPos.x, screenPos.y, zDistance));
                dragOffset = transform.position - clickWorldPos;

                Debug.Log($"[Tap] {gameObject.name} 선택됨 → Drag 시작");
            }
        }
    }

    private void ExecuteDrag(Vector2 screenPos)
    {
        Vector3 screenPoint = new Vector3(screenPos.x, screenPos.y, zDistance);
        Vector3 worldPos = mainCamera.ScreenToWorldPoint(screenPoint);

        // Y(높이)는 유지하고 수평면 위에서만 이동
        Vector3 newPos = worldPos + dragOffset;
        transform.position = new Vector3(newPos.x, transform.position.y, newPos.z);
    }

    // -------------------------------------------------------------
    // Snap 판정
    // -------------------------------------------------------------
    private void EndDragAndTrySnap()
    {
        isDragging = false;

        Transform nearest = FindNearestSnapPoint();
        if (nearest != null)
        {
            // 스냅 후보 발견 → Lerp 시작
            lerpTarget = new Vector3(
                nearest.position.x,
                transform.position.y,  // 높이는 유지
                nearest.position.z);
            isLerping = true;
            Debug.Log($"[Snap] {nearest.name}으로 스냅 → Lerp 시작");
        }
        else
        {
            Debug.Log("[Snap] 근처에 스냅 포인트 없음 → 제자리 유지");
        }
    }

    private Transform FindNearestSnapPoint()
    {
        Transform nearest = null;
        float minDist = snapDistance;  // 이 거리보다 가까운 것만 후보

        foreach (Transform p in snapPoints)
        {
            // 수평 거리만 측정 (Y축 무시)
            Vector3 a = new Vector3(transform.position.x, 0, transform.position.z);
            Vector3 b = new Vector3(p.position.x, 0, p.position.z);
            float d = Vector3.Distance(a, b);

            if (d < minDist)
            {
                minDist = d;
                nearest = p;
            }
        }
        return nearest;
    }

    // -------------------------------------------------------------
    // Lerp 이동
    // -------------------------------------------------------------
    private void HandleLerpMovement()
    {
        if (!isLerping) return;

        float dist = Vector3.Distance(transform.position, lerpTarget);
        if (dist > arriveThreshold)
        {
            // Time.deltaTime을 곱해 프레임률에 독립적으로 보간
            transform.position = Vector3.Lerp(
                transform.position,
                lerpTarget,
                lerpSpeed * Time.deltaTime);
        }
        else
        {
            transform.position = lerpTarget;
            isLerping = false;
            Debug.Log("[Lerp] 도착 완료");
        }
    }

    // -------------------------------------------------------------
    // Gizmo: 에디터에서 스냅 범위를 시각적으로 확인
    // -------------------------------------------------------------
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, snapDistance);
    }
}
